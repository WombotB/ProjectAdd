package com.example.demoN;
class test{  
    public static void main(){  
     System.out.println("Hello Java");  
    }  
}  